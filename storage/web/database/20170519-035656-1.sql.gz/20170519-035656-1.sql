-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- dsn     : mysql:host=192.168.16.222;dbname=yii2_shop
-- 
-- Part : #1
-- Date : 2017-05-19 03:56:56
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

